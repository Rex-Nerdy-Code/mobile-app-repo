package com.example.android.courtcounter;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    EditText teamANameCollector, teamBNameCollector;

    String TeamAName, TeamBName;
   
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.team_name);


        teamANameCollector = findViewById(R.id.team_a_name);
        teamBNameCollector = findViewById(R.id.team_b_name);

          TeamAName = teamANameCollector.getText().toString();
          TeamBName = teamBNameCollector.getText().toString();
    }

    public void goToCountPage(View view) {
        //send via intent to new activity
       Intent intent = new Intent(MainActivity2.this, MainActivity.class);
       intent.putExtra("TeamAvar", TeamAName);
       intent.putExtra("TeamBvar", TeamBName);
        MainActivity2.this.startActivity(intent);
    }
}