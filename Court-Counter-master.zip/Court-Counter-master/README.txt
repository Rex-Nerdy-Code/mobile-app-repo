Build Instructions
-------------------

This sample uses the Gradle build system. To build this project, use the
"gradlew build" command or use "Import Project" in Android Studio.

To see a list of all available commands, run "gradlew tasks".

Dependencies
-------------

- Android SDK Build-tools v24.0.2
- Android Support Repository v24.2.0

Dependencies are available for download via the Android SDK Manager.

Android Studio is available for download at:
    http://developer.android.com/sdk/installing/studio.html
